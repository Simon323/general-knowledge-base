javaX "Java 18" $args[0]
