javaX "Java 6" $args[0]
