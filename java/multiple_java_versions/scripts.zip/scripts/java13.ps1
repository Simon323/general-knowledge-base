javaX "Java 13" $args[0]
